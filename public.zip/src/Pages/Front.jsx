import React from 'react';
import styles from '../Styles/Front.module.css';
import nft_image_1 from '../Images/nft_front.png';
import nft_text from '../Images/NFT_text.png'
const Front = () => {
  return (<>

    <div className={styles.main_container}>
    <div className={styles.text_img}>
    <img src={nft_text}></img>    
    </div>
    <div className={styles.cont}>
        <div className={styles.cont_1}>
        <div className={styles.cont_01}>
            <h2>Explore, Collect and Sell NFTs</h2>
            <p>On the Worlds best and Biggest Marketplace</p>
            <div className={styles.cont_1_btn}>
                <button className={styles.explore_btn}>Explore</button>
                <button className={styles.create_btn}>Create</button>
            </div>
        </div>
                </div>

        <div className={styles.cont_2}>
            <img src={nft_image_1}></img>
        </div>
        </div>
    </div>


    {/* Live Auctions */}

    <div className={styles.auctions}>
    <div className={styles.auction_head}>
    <h2>Live Auctions</h2>
    <div className={styles.auction_sign}>
       <div>&#60;</div>
       <div className={styles.auction_less}>&#62;</div>
    </div>
    </div>
<div className={styles.nft_grids}>

<div className={styles.nft_auction}>
  <div className={styles.nft_img}></div>
  <button>Art</button>
  <div className={styles.nft_users}>
  <div className={styles.nft_user}>

<div className={styles.nft_user_img}></div>
<h2>User Artists</h2>
</div>

<div className={styles.nft_time}>
<p><span>12 Days 7hrs</span> left</p>
</div>

  </div>
  <h2>The Rusty Robots</h2>
  <p>Highest Bid</p>
  <div className={styles.nft_prices_likes}>
<div className={styles.nft_prices}><h3>1.05 ETH</h3></div>
<div className={styles.nft_likes}>
<h2><span>&#9829;</span> 40 </h2>
</div>

  </div>
  
</div>

<div className={styles.nft_auction}>
  <div className={styles.nft_img}></div>
  <button>Art</button>
  <div className={styles.nft_users}>
  <div className={styles.nft_user}>

<div className={styles.nft_user_img}></div>
<h2>User Artists</h2>
</div>

<div className={styles.nft_time}>
<p><span>12 Days 7hrs</span> left</p>
</div>

  </div>
  <h2>The Rusty Robots</h2>
  <p>Highest Bid</p>
  <div className={styles.nft_prices_likes}>
<div className={styles.nft_prices}><h3>1.05 ETH</h3></div>
<div className={styles.nft_likes}>
<h2><span>&#9829;</span> 40 </h2>
</div>

  </div>
  
</div>

<div className={styles.nft_auction}>
  <div className={styles.nft_img}></div>
  <button>Art</button>
  <div className={styles.nft_users}>
  <div className={styles.nft_user}>

<div className={styles.nft_user_img}></div>
<h2>User Artists</h2>
</div>

<div className={styles.nft_time}>
<p><span>12 Days 7hrs</span> left</p>
</div>

  </div>
  <h2>The Rusty Robots</h2>
  <p>Highest Bid</p>
  <div className={styles.nft_prices_likes}>
<div className={styles.nft_prices}><h3>1.05 ETH</h3></div>
<div className={styles.nft_likes}>
<h2><span>&#9829;</span> 40 </h2>

</div>

  </div>
  
</div>

<div className={styles.nft_auction}>
  <div className={styles.nft_img}></div>
  <button>Art</button>
  <div className={styles.nft_users}>
  <div className={styles.nft_user}>

<div className={styles.nft_user_img}></div>
<h2> User Artists</h2>
</div>

<div className={styles.nft_time}>
<p><span>12 Days 7hrs</span> left</p>

</div>

  </div>
  <h2>The Rusty Robots</h2>
  <p>Highest Bid</p>
  <div className={styles.nft_prices_likes}>
<div className={styles.nft_prices}><h3>1.05 ETH</h3></div>
<div className={styles.nft_likes}>
<h2><span>&#9829;</span> 40 </h2>
</div>

  </div>
  
</div>
</div>


    </div>


    {/* Top Collection */}

<div className={styles.collections}>

<div className={styles.collection_head}>
    <h2>Top Collections</h2>
    <div className={styles.collection_dates}>
    <h2>
    <span>Last 1 Day</span>  &#8964;
    </h2>
    </div>
    </div>


</div>

    </>

  )
}

export default Front