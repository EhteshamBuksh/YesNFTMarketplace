import React from 'react';
import Navbar from './Components/Navbar';
import './Styles/Navbar.css';
import Front from './Pages/Front'
const App = () => {
  return <>
<Navbar />
<Front/>
  </>;
};

export default App;
